package io.egen.springify;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
@Component
//@Scope("prototype")
public class Hello {
	public String version;
	
	public Hello(String ver){
		version=ver;
	}
	
	
	public void sayHello(){
		System.out.println(" Hello String");
		
	}
	

}
