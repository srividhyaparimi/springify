package io.egen.springify;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
@Configuration
@Component
public class Application {
	//@Bean
	public Hello getHello(String ver){
		return new Hello("4.5 RELEASE");
	}

}
